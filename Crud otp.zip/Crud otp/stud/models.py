from django.db import models
from django.contrib.auth.models import AbstractUser
from django import forms
from django.core.exceptions import ValidationError
from django.db import models
from django.utils import timezone
from django.contrib.auth.models import User
import uuid
import random
from django.conf import settings

# Create your models here.
class Studmodel(models.Model):
    name=models.CharField(max_length=100)
    mother_name=models.CharField(max_length=30)    
    father_name=models.CharField(max_length=30)
    department=models.CharField(max_length=30)
    division=models.CharField(max_length=1)
    address=models.CharField(max_length=100)
    mob_no=models.CharField(max_length=10,unique=True)
    city=models.CharField(max_length=30)

    def clean(self):
        if any(char.isdigit() for char in self.name):
            raise ValidationError("Name only contains charecters.")

        if any(char.isdigit() for char in self.mother_name):
            raise ValidationError("Mother name only contains charecters.")

        if any(char.isdigit() for char in self.father_name):
            raise ValidationError("Father name only contains charecters.")

        if any(char.isdigit() for char in self.department):
            raise ValidationError("Department only contains charecters.")
        
        if any(char.isdigit() for char in self.division):
            raise ValidationError("Division only contains charecters.")
        
        
        if any(char.isdigit() for char in self.city):
            raise ValidationError("City only contains charecters.")

        


    def save(self, *args, **kwargs):
        self.full_clean()  
        super().save(*args, **kwargs)    

class customuser(AbstractUser):
    mobile_number = models.CharField(max_length=20, unique=True)

    def __str__(self):
        return self.username


class OTP(models.Model):
    user = models.ForeignKey(customuser, on_delete=models.CASCADE)
    otp = models.CharField(max_length=6, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} - {self.otp}"
