from django.contrib.auth.models import User
from django.contrib.auth.forms import UserCreationForm
from django import forms
from django.core import validators
from .models import customuser
from stud.models import Studmodel
from django.core.exceptions import ValidationError


class Registration_form(UserCreationForm):
    email = forms.EmailField(required=True)
    mobile_number = forms.CharField(max_length=20, required=True)
    class Meta:
        model=customuser
        fields = ['username', 'first_name', 'last_name', 'email','mobile_number']
        labels = {'email': 'Email'}
       

    def clean_email(self):
        email = self.cleaned_data['email']
        
        if customuser.objects.filter(email=email).exists():
            raise forms.ValidationError("This email is already in use.")
        return email
    
    def clean_mobile_number(self):
        mobile_number = self.cleaned_data.get('mobile_number')
        if customuser.objects.filter(mobile_number=mobile_number).exists():
            raise forms.ValidationError("This mobile number is already in use.")
        return mobile_number
    

class StudmodelForm(forms.ModelForm):
    class Meta:
        model = Studmodel
        fields = '__all__'

    def clean_name(self):
        name = self.cleaned_data['name']
        if any(char.isdigit() for char in name):
            raise ValidationError("Name......... only contains characters.")

        return name

    def clean_mother_name(self):
        mother_name = self.cleaned_data['mother_name']
        if any(char.isdigit() for char in mother_name):
            raise ValidationError("Mother's name only contains characters.")

        return mother_name

    def clean_father_name(self):
        father_name = self.cleaned_data['father_name']
        if any(char.isdigit() for char in father_name):
            raise ValidationError("Father's name only contains characters.")

        return father_name
    

from django import forms
from django.contrib.auth.forms import SetPasswordForm


class OTPVerificationForm(forms.Form):
    otp = forms.CharField(max_length=6, label='OTP')


class PasswordResetForm(SetPasswordForm):
    def clean(self):
        cleaned_data = super().clean()
        new_password = cleaned_data['new_password']
        confirm_password = cleaned_data['confirm_password']

        if new_password != confirm_password:
            raise forms.ValidationError("Passwords do not match.")

