from django.shortcuts import render
from .models import *
from django.shortcuts import render, HttpResponseRedirect, redirect, get_object_or_404
from django.urls import reverse
from django.contrib.auth.forms import AuthenticationForm,PasswordResetForm
from django.contrib import messages
from .form import Registration_form
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.core.exceptions import ValidationError
import sqlalchemy
from sqlalchemy.exc import IntegrityError
from stud.models import Studmodel, customuser
from django.db import IntegrityError

from django.core.mail import send_mail
import random
import string
from django.contrib.auth.hashers import make_password



def base(request):
    return render (request, 'base.html')

def log_in(request):
    if request.method =='POST':
        lfm = AuthenticationForm(request=request, data=request.POST)
        if lfm.is_valid():
            uname = lfm.cleaned_data['username']
            upass = lfm.cleaned_data['password']
            user = authenticate(username=uname, password=upass)
            if user is not None:
                login(request, user)
                messages.success(request,'Successfully Logged In!!')
                return HttpResponseRedirect('/show/')
    else:
        lfm = AuthenticationForm()
    return render(request, 'login.html', {'form': lfm})

def registration(request):
    if request.method=='POST':
        rfm=Registration_form(request.POST)
        if rfm.is_valid():
            messages.success(request, 'Successfully Registered!!')
            rfm.save()
            # customuser.objects.create(rfm=rfm, mobile_number=rfm.cleaned_data['mobile_number'])
            return HttpResponseRedirect('/login/')
    else:
        rfm=Registration_form()        
    return render(request, 'reg_form.html', {'form':rfm})


def add(request):
    if request.method=='POST':
        name=request.POST['name']
        mother_name=request.POST['mother_name']
        father_name=request.POST['father_name']
        department=request.POST['department']
        division=request.POST['division']
        address=request.POST['address']
        mob_no=request.POST['mob_no']
        city=request.POST['city']

        
        try:
            studs=Studmodel(name=name,mother_name=mother_name,department=department,father_name=father_name,division=division,address=address,mob_no=mob_no,city=city)
            studs.save()
            print('------------1>',ValidationError)
            return HttpResponseRedirect(reverse('show'))
        
        except IntegrityError as e:
            # error_message = str(e)
            # if "Duplicate entry" in error_message and "mob_no" in error_message:
            #     error_message = "The mobile number you are trying to add already exists."    
                
                return render(request, 'add.html', {'error_message': e}) 
        except ValidationError as ve:
            # print('--->',ValidationError)
            # Handle ValueError and render error_message in the template
            # error_message = "{}".format(ve)
            # print('---------------->',error_message)
            return render(request, 'add.html', {'error_message': ve})  
        # finally:
        #     print('--->',ValidationError)  
    return render(request, 'add.html')



def show(request):
    if request.user.is_authenticated:
        studs = Studmodel.objects.all()
        # studs=Studmodel.objects.all
        context={
        'studs':studs
    }
    
    return render(request, 'show.html', context)

def update(request,id):
    if request.method=='POST':
        name=request.POST['name']
        mother_name=request.POST['mother_name']
        father_name=request.POST['father_name']
        department=request.POST['department']
        division=request.POST['division']
        address=request.POST['address']
        mob_no=request.POST['mob_no']
        city=request.POST['city']
        try:
            studs=Studmodel.objects.get(id=id)
            studs.name=name
            studs.mother_name=mother_name
            studs.father_name=father_name
            studs.department=department
            studs.division=division
            studs.address=address
            studs.mob_no=mob_no
            studs.city=city
            studs.save()
            return HttpResponseRedirect(reverse('show'))
        
        except IntegrityError as e:
            error_message = str(e)
            if "Duplicate entry" in error_message and "mob_no" in error_message:
                error_message = "The mobile number you are trying to update already exists."
                return render(request, 'update.html', {'error_message': error_message})
            
    studs= Studmodel.objects.get(id=id)
    context = {
        "studs": studs
    }
    return render(request, 'update.html', context)

def delete(request,id):
    studs=Studmodel.objects.get(id=id)
    studs.delete()
    return HttpResponseRedirect(reverse('show'))
   
   

def log_out(request):
    logout(request)
    return HttpResponseRedirect('/login/')




# below generate_otp function is for gmail
# def generate_otp():
#     # Generate a 6-digit OTP
#     digits = string.digits
#     return ''.join(random.choice(digits) for i in range(6))


def password_reset_request(request):
    if request.method == 'POST':
        form = PasswordResetForm(request.POST)
        if form.is_valid():
            email = form.cleaned_data['email']
            user = get_object_or_404(customuser, email=email)
            
            # # Generate OTP
            # otp = generate_otp()
            # password_reset_token = OTP.objects.create(user=user, otp=otp)

            # mail_subject = 'Password Reset Request'
            # message = f"Your OTP for password reset is: {otp}"
            # email = EmailMessage(mail_subject, message, to=[email])
            # email.send()
            # OTP.otp.delete()
            # messages.success(request, 'OTP sent successfully. Please check your inbox and enter the OTP to reset your password.')
            otp = random.randint(111111, 999999)

            subject = 'OTP Verification'

            message = f'Hello  \n This is your OTP {otp}. \n Kindly Do not share Your OTP.\n\n '

            email_from = settings.EMAIL_HOST_USER

            recipient_list = [email]

            send_mail(subject, message, email_from, recipient_list)
            messages.success(request, 'OTP sent successfully. Please check your inbox and enter the OTP to reset your password.')

            return redirect('verify_otp', user_id=user.id)
    else:
        form = PasswordResetForm()
    return render(request, 'reset_password.html', {'form': form})


def verify_otp(request, user_id):
    # user = get_object_or_404(customuser, id=user_id) for the gmail
    if request.method == 'POST':
        entered_otp = request.POST.get('otp')
        try:
            pass
            # otp_obj = get_object_or_404(OTP, user=user, otp=entered_otp)  for the gmail
        # print(otp_obj)
        
        except OTP.DoesNotExist:
            messages.error(request, 'Invalid OTP. Please try again.')
            return redirect('verify_otp', user_id=user_id)
        return redirect('reset_password',user_id=user_id)
    return render(request, 'verify_otp.html')

def reset_password(request, user_id):
    user = get_object_or_404(customuser, id=user_id)
    if request.method=='POST':
        password=request.POST.get('password')
        confirm_password=request.POST.get('confirm_password')

        if password==confirm_password:
            user.password=make_password(password)   
            user.save()

            OTP.objects.filter(user=user).delete()

            messages.success(request, 'Password reset successful. Please login with your new password.')
            return redirect('login')
        
        else:
            messages.error(request, 'Password donot match.')
            return render(request, 'reset_password_form.html', {'user_id':user_id})
    return render(request, 'reset_password_form.html', {'user_id':user_id})   
