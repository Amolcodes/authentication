from django.contrib import admin
from .models import Studmodel
# Register your models here.
@admin.register(Studmodel)
class AdminStudmodel(admin.ModelAdmin):
    list_display=('id','name','mother_name','father_name','department','division','address','mob_no','city')

 