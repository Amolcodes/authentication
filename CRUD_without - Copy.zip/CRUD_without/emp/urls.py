from django.contrib import admin
from django.urls import path
from emp import views

app_name = 'emp' 

urlpatterns = [
    path('admin/', admin.site.urls),
    path('',views.base_view,name='base'),
    path('add/',views.add_emp_view,name='add'),
    path('show/',views.show_emp_view,name='show'),
    path('update/<int:emp_id>/',views.update_emp_view,name='update'),
    path('delete/<int:emp_id>/',views.delete_emp_view,name='delete'),
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/',views.logout_view,name='logout'),
    path('forget_pass/',views.forget_pass,name='forget_pass'),
    path('confirm_pass/<int:user_id>/',views.confirm_pass,name='confirm_pass'),
    path('verify_otp/<int:user_id>/', views.verify_otp, name='verify_otp'),

]