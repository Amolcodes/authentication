from .sql import INSERT_EMPLOYEE_QUERY, SELECT_EMPLOYEE_QUERY, UPDATE_EMPLOYEE_QUERY, DELETE_EMPLOYEE_QUERY, SELECT_ALL_EMPLOYEES,INSERT_REGISTER_EMP_QUERY,CHECK_REG_USER_QUERY,SELECT_USER_QUERY,create_auth_tokens_query,SELECT_EMAIL_QUERY,INSERT_OTP_QUERY,SELECT_OTP_QUERY,UPDATE_PASSWORD_QUERY
from django.db import connection, IntegrityError

class InvalidNameError(Exception):
    pass

def add_emp(Full_Name,Designation,Gender,Date_of_joining,Year_of_Experience,City,Email,Mobile_Number,Marital_Status):
    if any(char.isdigit() for char in Full_Name):
                raise InvalidNameError("Fullname only contains characters.")
    else:
        try:
            Year_of_Experience=int(Year_of_Experience)

            with connection.cursor() as cursor:
                cursor.execute(INSERT_EMPLOYEE_QUERY,[Full_Name,Designation,Gender,Date_of_joining,Year_of_Experience,City,Email,Mobile_Number,Marital_Status])

        except ValueError:
            raise  ValueError('Year of experience must be integer')

        except InvalidNameError:
            raise  InvalidNameError('Year of experience must be integer')

        except mysql.connector.IntegrityError as e:
            if 'UNIQUE constraint failed' in str(e):
                raise ValueError('Email or Mobile number already exist') 
            else:
                raise IntegrityError('An error occurred while updating the employee')  
          
        
def show_emp(emp_id):
    with connection.cursor() as cursor:
        cursor.execute(SELECT_EMPLOYEE_QUERY,[emp_id])        
        return cursor.fetchone()
    
def update_emp(Full_Name, Designation, Gender, Date_of_joining, Year_of_Experience, City, Email, Mobile_Number, Marital_Status, emp_id):
    try:
        Year_of_Experience = int(Year_of_Experience)

        with connection.cursor() as cursor:
            cursor.execute(UPDATE_EMPLOYEE_QUERY, [Full_Name, Designation, Gender, Date_of_joining, Year_of_Experience, City, Email, Mobile_Number, Marital_Status, emp_id])

    except ValueError:
        raise ValueError('Year of experience must be an integer')

    except IntegrityError as e:
        if 'UNIQUE constraint failed' in str(e):
            raise ValueError('Email or Mobile number already exists')
        else:
            raise IntegrityError('An error occurred while updating the employee')    
    
        
def delete_emp(emp_id):
    with connection.cursor() as cursor:
        cursor.execute(DELETE_EMPLOYEE_QUERY, [emp_id])
        connection.commit()

def get_all_emp():
    with connection.cursor() as cursor:
        cursor.execute(SELECT_ALL_EMPLOYEES)
        return cursor.fetchall()                
        

from passlib.hash import bcrypt
import mysql.connector


def register_user(username, first_name, last_name, email, contact_number, password):
    try:
        password_hash = bcrypt.hash(password)

        with connection.cursor() as cursor:
            cursor.execute(INSERT_REGISTER_EMP_QUERY, [username, first_name, last_name, email, contact_number, password_hash])

        connection.commit()

    except mysql.connector.IntegrityError as e:
        if 'UNIQUE constraint failed' in str(e):
            raise ValueError('Username, email, or contact number already exists')
        else:
            raise ValueError('An error occurred while registering the user')

def register_user(username, first_name, last_name, email, contact_number, password_hash):
    try:

        with connection.cursor() as cursor:
            cursor.execute(INSERT_REGISTER_EMP_QUERY, [username, first_name, last_name, email, contact_number, password_hash])

        connection.commit()

    except mysql.connector.IntegrityError as e:
        if 'UNIQUE constraint failed' in str(e):
            raise ValueError('Username, email, or contact number already exists')
        else:
            raise ValueError('An error occurred while registering the user')

def authenticate_user(username, password):
    with connection.cursor() as cursor:
        cursor.execute(CHECK_REG_USER_QUERY, [username])
        result = cursor.fetchone()

    if result and bcrypt.verify(password, result[0]):
        return True
    else:
        return False 
 

def check_user(SELECT_USER_QUERY, username):
    with connection.cursor() as cursor:
        cursor.execute(SELECT_USER_QUERY, (username,))
        user_data = cursor.fetchone()
        print(user_data)
        if user_data:
            user_dict = {
                'id': user_data[0],
                'username': user_data[1],
                'password_hash': user_data[2]
            }
            return user_dict
        else:
            return None          

import secrets
import string

def generate_session_token(length=32):
    alphabet = string.ascii_letters + string.digits
    session_token = ''.join(secrets.choice(alphabet) for _ in range(length))
    return session_token

def create_token_table():
    with connection.cursor() as cursor:
        cursor.execute(create_auth_tokens_query)
        


def check_email(SELECT_EMAIL_QUERY, email):
    with connection.cursor() as cursor:
        cursor.execute(SELECT_EMAIL_QUERY, (email,))
        user_email = cursor.fetchone()
        if user_email:
            user_dict = {
                'id': user_email[0],
                'username': user_email[1],        
            }
            return user_dict
        else:
            return None 

def insert_otp(otp,created_time,user_id):
    with connection.cursor() as cursor:
        cursor.execute(INSERT_OTP_QUERY, (otp, created_time, user_id))          
    connection.commit() 
    connection.close() 

def check_otp(SELECT_OTP_QUERY,entered_otp,user_id):
    with connection.cursor() as cursor:
        cursor.execute(SELECT_OTP_QUERY,(entered_otp,user_id))
        otp_data=cursor.fetchone()
        return otp_data


def update_password_in_database(user_id, new_password):
    with connection.cursor() as cursor:
        cursor.execute(UPDATE_PASSWORD_QUERY, [new_password, user_id])
    




