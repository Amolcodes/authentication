import mysql.connector


# Replace the below values with your actual MySQL database credentials
DB_HOST = '127.0.0.1'
DB_USER = 'root'
DB_PASSWORD = 'AmolAN'
DB_DATABASE = 'emp_db'

# Connect to the MySQL database
connection = mysql.connector.connect(
    host=DB_HOST,
    user=DB_USER,
    password=DB_PASSWORD,
    database=DB_DATABASE
)
cursor = connection.cursor()


CREATE_TABLE_QUERY = '''
CREATE TABLE IF NOT EXISTS emp(
    id INTEGER PRIMARY KEY AUTO_INCREMENT,
    Full_Name varchar(100) NOT NULL,
    Designation varchar(100) NOT NULL,
    Gender varchar(10) NOT NULL,
    Date_of_joining DATE NOT NULL,
    Year_of_Experience INT NOT NULL,
    City varchar(30) NOT NULL,
    Email varchar(100) UNIQUE NOT NULL,
    Mobile_Number varchar(10) UNIQUE NOT NULL,
    Marital_Status varchar(10) NOT NULL
)
'''


cursor.execute(CREATE_TABLE_QUERY)

connection.commit()



INSERT_EMPLOYEE_QUERY='''
INSERT INTO emp(Full_Name,Designation,Gender,Date_of_joining,Year_of_Experience,City,Email,Mobile_Number,Marital_Status)
VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s)
'''

SELECT_EMPLOYEE_QUERY='''
SELECT * FROM emp WHERE id=%s
'''

UPDATE_EMPLOYEE_QUERY = '''
UPDATE emp
SET Full_Name=%s, Designation=%s, Gender=%s, Date_of_joining=%s, Year_of_Experience=%s, City=%s, Email=%s, Mobile_Number=%s, Marital_Status=%s
WHERE id=%s
'''


DELETE_EMPLOYEE_QUERY='''
DELETE FROM emp WHERE id=%s
'''

SELECT_ALL_EMPLOYEES='''
SELECT * FROM emp
'''



CREATE_TABLE_REGISTER_EMP_QUERY='''
CREATE TABLE IF NOT EXISTS emp_reg(
id INTEGER PRIMARY KEY AUTO_INCREMENT,
username varchar(50) UNIQUE NOT NULL,
first_name varchar(50) NOT NULL,
last_name varchar(50) NOT NULL,
email varchar(100) UNIQUE NOT NULL,
contact_number varchar(10) UNIQUE NOT NULL,
password_hash varchar(200) UNIQUE NOT NULL
)
'''
cursor.execute(CREATE_TABLE_REGISTER_EMP_QUERY)
connection.commit()



INSERT_REGISTER_EMP_QUERY='''
INSERT INTO emp_reg(username,first_name,last_name,email,contact_number,password_hash)
VALUES (%s, %s, %s, %s, %s, %s)
'''

CHECK_REG_USER_QUERY='''SELECT id, username, password_hash FROM emp_reg WHERE username=%s'''




SELECT_USER_QUERY = '''
        SELECT * FROM emp_reg
        WHERE username=%s
        '''

create_auth_tokens_query ='''
CREATE TABLE IF NOT EXISTS auth_tokens(
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    session_token VARCHAR(100) NOT NULL,
    expiration_time DATETIME NOT NULL,
    FOREIGN KEY (user_id) REFERENCES emp_reg (id) ON DELETE CASCADE
);
'''


SELECT_EMAIL_QUERY = '''
        SELECT id,username FROM emp_reg
        WHERE email=%s
        '''


CREATE_TABLE_SEND_OTP_QUERY='''
CREATE TABLE IF NOT EXISTS sended_otp(
id INTEGER PRIMARY KEY AUTO_INCREMENT,
otp INT NOT NULL,
created_time DATETIME NOT NULL,
user_id INTEGER NOT NULL,
FOREIGN KEY (user_id) REFERENCES emp_reg (id) ON DELETE CASCADE
)
'''
cursor.execute(CREATE_TABLE_SEND_OTP_QUERY)

connection.commit()


INSERT_OTP_QUERY = '''
    INSERT INTO sended_otp (otp, created_time,user_id)
    VALUES (%s, %s, %s)
    '''

  


SELECT_OTP_QUERY='''
SELECT otp FROM sended_otp WHERE otp=%s AND user_id=%s

'''
    

UPDATE_PASSWORD_QUERY = '''
UPDATE emp_reg SET password_hash = %s WHERE id = %s
'''