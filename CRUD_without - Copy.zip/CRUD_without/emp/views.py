from django.shortcuts import render,redirect,HttpResponse
from .crud import add_emp,show_emp,update_emp,delete_emp,get_all_emp,generate_session_token,check_user,create_token_table,InvalidNameError,check_email,insert_otp,check_otp,update_password_in_database
from django.db import IntegrityError
from .sql import connection,SELECT_USER_QUERY,SELECT_EMAIL_QUERY,SELECT_OTP_QUERY
from django.contrib import messages


# Create your views here.

def base_view(request):
    return render(request, 'base.html')

def add_emp_view(request):
    if "username" in request.session:
        error_message = ''
        if request.method=='POST':
            full_name=request.POST['full_name']
            designation=request.POST['designation']
            gender=request.POST['gender']
            date_of_joining=request.POST['date_of_joining']
            year_of_experience=request.POST['year_of_experience']
            city=request.POST['city']
            email=request.POST['email']
            mobile_number=request.POST['mobile_number']
            marital_status=request.POST['marital_status']  

            try:
                add_emp(full_name, designation, gender, date_of_joining, year_of_experience, city, email, mobile_number, marital_status)
                return redirect('emp:show')
            except InvalidNameError as e:
                error_message = str (e)
            except ValueError as e:
                error_message = str(e)
            except IntegrityError as e:
                error_message = str(e)
               

        return render(request, 'add_emp.html', {'error_message': error_message})
    return render(request, 'base.html', {'error_message': 'you are not logged in !!!'})

def show_emp_view(request):
    if "username" in request.session:
        employ=get_all_emp() 
        return render(request, 'show_emp.html', {'employ': employ})
    else:
        return redirect('emp:login')

def update_emp_view(request, emp_id):
    if "username" in request.session:
        employee = show_emp(emp_id)
        error_message = ''

        if request.method == 'POST':
            full_name = request.POST['full_name']
            designation = request.POST['designation']
            gender = request.POST['gender']
            date_of_joining = request.POST['date_of_joining']
            year_of_experience = request.POST['year_of_experience']
            city = request.POST['city']
            email = request.POST['email']
            mobile_number = request.POST['mobile_number']
            marital_status = request.POST['marital_status']
            
            date_of_joining = datetime.strptime(request.POST['date_of_joining'], '%b. %d, %Y').strftime('%Y-%m-%d')
            try:
                update_emp(full_name, designation, gender, date_of_joining, year_of_experience, city, email, mobile_number, marital_status, emp_id)
                return redirect('emp:show')  
            except ValueError as e:
                error_message = str(e)
            except IntegrityError as e:
                error_message = str(e)

        return render(request, 'update.html', {'employee': employee, 'error_message': error_message})
    return render(request, 'base.html', {'error_message': 'you are not logged in !!!'})
def delete_emp_view(request, emp_id):
    delete_emp(emp_id)
    return redirect('emp:show')

from .crud import register_user

def register_view(request):

    if request.method == 'POST':
        username = request.POST['username']
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        email = request.POST['email']
        contact_number = request.POST['contact_number']
        password_hash = request.POST['password']

        try:
            register_user(username, first_name, last_name, email, contact_number, password_hash)
            messages.success(request, 'Successfully Registered!!')

            return redirect('emp:login')  
        except IntegrityError as e:
            print(str(e))
            if 'Duplicate entry' in str(e):
                error_message = 'Username or contact or email already exists.'
            else:
                error_message = 'An error occurred during registration.'

            return render(request, 'register.html', {'error_message': error_message})

    return render(request, 'register.html')


from datetime import datetime, timedelta
import bcrypt
def login_view(request):  
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
       
        user_data = check_user(SELECT_USER_QUERY, username)
        if user_data and password:
            create_token_table()
            session_token = generate_session_token()
            expiration_time = datetime.now() + timedelta(hours=1)

            insert_token_query = '''
                INSERT INTO auth_tokens(user_id, session_token, expiration_time)
                VALUES (%s, %s, %s)
            '''
            with connection.cursor() as cursor:
                cursor.execute(insert_token_query, (user_data['id'], session_token, expiration_time))
    
            request.session['username'] = username
            request.session.save()
            messages.success(request, 'You have successfully logged in.')
            response = redirect('emp:show') 
            response.set_cookie('session_token', session_token, httponly=True)
            return response  
        else:
            error_message = 'Invalid username or password'
            return render(request, 'login.html', {'error_message': error_message})

    return render(request, 'login.html')

from django.views.decorators.cache import never_cache
from django.shortcuts import redirect
from django.db import connection

@never_cache
def logout_view(request):
    if "username" in request.session:
        # Delete the 'username' key from the session to log the user out
        del request.session["username"]

    if request.method == 'POST':
        if 'session_token' in request.COOKIES:
            session_token = request.COOKIES['session_token']

            delete_token_query = '''
                DELETE FROM auth_tokens WHERE session_token = %s
            '''
            with connection.cursor() as cursor:
                cursor.execute(delete_token_query, (session_token,))

            response = redirect('emp:base')
            response.delete_cookie('session_token')

            response['Cache-Control'] = 'no-cache, no-store, must-revalidate'
            response['Pragma'] = 'no-cache'
            response['Expires'] = '0'
            return response
    return redirect('emp:show')



from datetime import datetime
import employee.settings
import random
from django.core.mail import send_mail
from django.template.loader import render_to_string

def forget_pass(request):
    if request.method == 'POST':
        email = request.POST.get('email')

        if email:
            user_email = check_email(SELECT_EMAIL_QUERY, email)

            if user_email:
                otp = random.randint(111111, 999999)

                created_time = datetime.now()

                insert_otp(otp, created_time, user_email['id'])

                k=user_email['username']

                subject = 'OTP Verification'

                message = f'Hello {k} \n This is your OTP {otp}. \n Kindly Do not share Your OTP.\n\n \n\n\n Thanks \n {employee.settings.EMAIL_HOST_USER}'
                
                email_from = employee.settings.EMAIL_HOST_USER

                recipient_list = [email]

                send_mail(subject, message, email_from, recipient_list)
                messages.success(request, 'OTP sent successfully. Please check your inbox and enter the OTP to reset your password.')
                context = {'user_id': user_email['id']}
                print(context)
                return render(request, 'verify_otp.html', context)
            else:
                messages.error(request, 'User email not found.')
                return render(request, 'forget_pass.html')
        else:
            messages.error(request, 'Email field is required.')
            return render(request, 'forget_pass.html')
    else:
        return render(request, 'forget_pass.html')
        


def verify_otp(request,user_id):
    if request.method =='POST':
        entered_otp = request.POST.get('otp')
        user_id = request.POST.get('userid')
        otp_data = check_otp(SELECT_OTP_QUERY, entered_otp,user_id) 

        if otp_data and otp_data[0] == int(entered_otp):
            return render(request, 'confirm_pass.html', {'user_id': user_id})
        else:
            messages.error(request, 'Invalid OTP. Please try again.')
            return render(request, 'verify_otp.html', {'user_id': user_id})   
    else:
        return render(request, 'verify_otp.html', {'user_id': user_id})    


def confirm_pass(request, user_id):
    if request.method == 'POST':
        new_password = request.POST['new_password']
        confirm_password = request.POST['confirm_password']

        if new_password != confirm_password:
            messages.error(request, "Passwords do not match. Please try again.")
            return render(request, 'confirm_pass.html', {'user_id': user_id})

        if update_password_in_database(user_id, new_password):
            messages.success(request, "Password updated successfully.")
            return redirect('emp:login')
        else:
            messages.success(request, "Password updated successfully.")
            return redirect('emp:login')      
    else:
        return render(request, 'confirm_pass.html', {'user_id': user_id})

